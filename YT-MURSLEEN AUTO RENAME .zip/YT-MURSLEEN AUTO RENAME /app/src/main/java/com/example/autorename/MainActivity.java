package com.example.autorename;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.io.File;

public class MainActivity extends Activity {

    private final String obbPath = "/storage/emulated/0/Android/obb/com.tencent.ig/";
    private final String dataPath = "/storage/emulated/0/Android/data/com.tencent.ig/";
    private final String obbNew = "/storage/emulated/0/Android/obb/com.tencent.ig_YT-MURSLEEN/";
    private final String dataNew = "/storage/emulated/0/Android/data/com.tencent.igYT-MURSLEEN/";

    private LinearLayout welcomeLayout;
    private LinearLayout mainLayout;
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Permissions Check
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        }

        welcomeLayout = findViewById(R.id.welcomeLayout);
        mainLayout = findViewById(R.id.mainLayout);
        Button btnJoinTelegram = findViewById(R.id.btnJoinTelegram);
        Button btnRename = findViewById(R.id.btnRename);
        Button btnUnrename = findViewById(R.id.btnUnrename);
        Button btnUninstall = findViewById(R.id.btnUninstall); // New Button for Uninstall

        // Check if the welcome voice should play
        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        boolean isFirstTime = prefs.getBoolean("firstTime", true);

        if (isFirstTime) {
            playWelcomeVoice();
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("firstTime", false);
            editor.apply();
        }

        // Show welcome message for 5 seconds
		new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					welcomeLayout.setVisibility(View.GONE);
					mainLayout.setVisibility(View.VISIBLE);
				}
			}, 3000); // 3 seconds delay

        btnJoinTelegram.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					openTelegramChannel();
				}
			});

        btnRename.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					renameFiles(true);
				}
			});

        btnUnrename.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					renameFiles(false);
				}
			});

        // Uninstall PUBG Mobile
        btnUninstall.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					uninstallPUBG();
				}
			});
    }

    private void playWelcomeVoice() {
        mediaPlayer = MediaPlayer.create(this, R.raw.mursleen);
        mediaPlayer.start();
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					mediaPlayer.release();
				}
			});
    }

    private void renameFiles(boolean rename) {
        File obbFile = new File(rename ? obbPath : obbNew);
        File dataFile = new File(rename ? dataPath : dataNew);
        File obbFileNew = new File(rename ? obbNew : obbPath);
        File dataFileNew = new File(rename ? dataNew : dataPath);

        if (!obbFile.exists() || !dataFile.exists()) {
            Toast.makeText(MainActivity.this, "❌ OBB/Data files not found!", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean obbSuccess = obbFile.renameTo(obbFileNew);
        boolean dataSuccess = dataFile.renameTo(dataFileNew);

        if (obbSuccess && dataSuccess) {
            Toast.makeText(MainActivity.this, rename ? "✅ Files Renamed!" : "✅ Files Restored!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MainActivity.this, "❌ Error renaming files!", Toast.LENGTH_SHORT).show();
        }
    }

    private void openTelegramChannel() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/yt_mursleen_cheats_mods"));
        startActivity(intent);
    }

    // New Function to Uninstall PUBG Mobile
    private void uninstallPUBG() {
        Intent intent = new Intent(Intent.ACTION_DELETE);
        intent.setData(Uri.parse("package:com.tencent.ig"));
        startActivity(intent);
    }
}
